﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8020210044_Pertemuan_04
{
    class Program
    {
        static void Main(string[] args)
        {
            String nama_lengkap, alamat; //deklarasi variabel dengan tipe data string tanpa nilai awal (belum ada isi)
            int usia, jumlah_saudara; //deklarasi variabel dengan tipe datta integer tanpa nilai awal (belum ada isi)
            double berat_badan; //deklarasi varaibel dengan tipe data double tanpa nilai awal (belum ada isi)
            bool status; //deklarasi variabel dengan tipe data boolean tanpa nilai awal (belum ada isi)
            Console.WriteLine("INPUT DATA");
            Console.WriteLine("==========");
            Console.Write("Input Nama Lengkap   : ");
            nama_lengkap = Console.ReadLine(); //untuk mengambil input keyboard & dan menyimpannya ke variabel nama_lengkap tanpa konversi data
            Console.Write("Input Usia Sekarang  : ");
            usia = int.Parse(Console.ReadLine()); //untuk mengambil input keyboard & menyimpannya ke variabel usia dengan konversi data ke integer
            Console.Write("Input Berat Badan    : ");
            berat_badan = double.Parse(Console.ReadLine()); //untuk mengambil input keyboard & menyimpannya ke variabel berat_badan dengan konversi data ke double
            Console.Write("Input Alamat         : ");
            alamat = Console.ReadLine(); //untuk mengambil input keyboard dan menyimpannya ke variabel alamat tanpa koversi data
            Console.Write("Input Jumlah Saudara : ");
            jumlah_saudara = int.Parse(Console.ReadLine()); //untuk mengambil input keyboard & menyimpannya ke variabel jumlah_saudara dengan konversi data ke integer
            Console.Write("Input Status         : ");
            status = bool.Parse(Console.ReadLine()); //untuk mengambil input keyboard & menyimpannya ke variabel status dengan konversi data ke boolean
            Console.WriteLine();
            Console.WriteLine("OUTPUT DATA");
            Console.WriteLine("===========");
            Console.WriteLine("Nama Lengkap   : " + nama_lengkap);
            Console.WriteLine("Usia Sekarang  : " + usia + " Tahun");
            Console.WriteLine("Berat Badan    : " + berat_badan + " KG");
            Console.WriteLine("Alamat         : " + alamat);
            Console.WriteLine("Jumlah Saudara : " + jumlah_saudara + " Orang");
            Console.WriteLine("Status         : " + status);
            Console.ReadKey();

        }
    }
}
